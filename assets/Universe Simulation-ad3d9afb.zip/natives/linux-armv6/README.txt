This folder contains deprecated plain native libraries for platform linux-armv6, please use the native JAR files in the jar folder.
