package Bildverarbeitung.exceptions;

public class NoRelationsException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoRelationsException (String message) {
        super(message);
    }
}
