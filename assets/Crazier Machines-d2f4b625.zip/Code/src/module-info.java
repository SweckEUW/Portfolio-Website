module jfx {
	exports Simulation;
	exports UI;
	exports MAIN;
 
	requires gluegen.rt;
	requires java.desktop;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.swing;
	requires jogl.all;
	requires javafx.media;
	requires javafx.fxml;
}